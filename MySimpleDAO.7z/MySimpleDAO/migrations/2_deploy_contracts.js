const MyDAO = artifacts.require('MyDAO')

module.exports = async function (deployer) {
	await deployer.deploy(MyDAO)
}
