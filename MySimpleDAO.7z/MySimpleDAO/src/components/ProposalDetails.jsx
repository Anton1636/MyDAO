import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
	Bar,
	BarChart,
	CartesianGrid,
	Legend,
	Tooltip,
	XAxis,
	YAxis,
} from 'recharts'
import { getProposal, voteOnProposal } from '../Blockchain.services'
import { daysRemaining, useGlobalState } from '../store'

const ProposalDetails = () => {
	const { id } = useParams()
	const [proposal, setProposal] = useState()
	const [data, setData] = useState([])
	const [isStakeholder] = useGlobalState('isStakeholder')

	const retrieveProposal = async () => {
		await getProposal(id).then(res => {
			setProposal(res)
			setData([
				{
					name: 'Voters',
					Acceptees: res?.upVotes,
					Rejectees: res?.downVotes,
				},
			])
		})
	}

	const onVote = async choice => {
		if (new Date().getTime() > Number(proposal.duration + '000')) {
			toast.warning('Proposal expired')
			return
		} else {
			await voteOnProposal(id, choice)
			toast.success('Voted successfully')
		}
	}

	useEffect(() => {
		retrieveProposal()
	}, [])
	return (
		<div className='p-8'>
			<h2 className='mb-5 font-semibold text-3xl'>{proposal?.title}</h2>
			<p>
				This proposal is to payout <strong>{proposal?.amount} ETH</strong> and
				currently have{' '}
				<strong>{proposal?.upVotes + proposal?.downVotes} votes</strong> and
				will expire in <strong>{daysRemaining(proposal?.duration)}</strong>
			</p>
			<hr className='my-6 border-gray-300 dark:border-r-gray-500' />
			<p>{proposal?.description}</p>
			<div className='flex justify-start items-center w-full mt-4 overflow-auto'>
				<BarChart width={730} height={250} data={data}>
					<CartesianGrid strokeDasharray='3 3' />
					<XAxis dataKey={name} />
					<YAxis />
					<Tooltip />
					<Legend />
					<Bar dataKey='Acceptees' fill='#2563eb' />
					<Bar dataKey='Rejectees' fill='#dc2626' />
				</BarChart>
			</div>
			{isStakeholder ? (
				<div
					className='flex justify-start items-center space-x-3 mt-4'
					role='group'
				>
					<button
						type='button'
						className='bg-transparent px-4 py-2.5 font-medium rounded-full  text-sm 
        leading-tight uppercase text-blue-600 shadow-md shadow-gray-400 active:bg-blue-800 dark:shadow-transparent transition duration-150 ease-in-out 
        dark:border dark:border-blue-500  border: border-blue-600 hover:text-white hove:bg:blue-600'
						onClick={() => onVote(true)}
					>
						Accept
					</button>
					<button
						type='button'
						className='bg-transparent px-4 py-2.5 font-medium rounded-full  text-sm 
        leading-tight uppercase text-red-600 shadow-md shadow-gray-400 active:bg-red-800 dark:shadow-transparent transition duration-150 ease-in-out 
        dark:border dark:border-red-500  border: border-red-600 hover:text-white hove:bg:red-600'
						onClick={() => onVote(false)}
					>
						Reject
					</button>
				</div>
			) : null}
		</div>
	)
}

export default ProposalDetails
