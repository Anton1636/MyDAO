import React, { useState } from 'react'
import Identicons from 'react-identicons'
import { Link } from 'react-router-dom'
import { daysRemaining, useGlobalState } from '../store'

const Proposals = () => {
	const [data] = useGlobalState('proposals')
	const [proposals, setProposals] = useState(data)

	const active = `bg-blue-600 px-4 py-2.5 font-medium text-white text-sm 
        leading-tight uppercase shadow-md shadow-gray-400 active:bg-blue-800 dark:shadow-transparent transition duration-150 ease-in-out 
        dark:border dark:border-blue-500  border: border-blue-600 hover:text-white`

	const deactivate = `bg-transparent px-4 py-2.5 font-medium  text-sm 
        leading-tight uppercase text-blue-600 shadow-md shadow-gray-400 active:bg-blue-800 dark:shadow-transparent transition duration-150 ease-in-out 
        dark:border dark:border-blue-500  border: border-blue-600 hover:text-white hove:bg:blue-600`

	const getAll = () => setProposals(data)
	const getOpened = () =>
		setProposals(
			data.filter(
				proposal => Date().getTime() < Number(proposal.duration) + '000'
			)
		)

	const getClosed = () =>
		setProposals(
			data.filter(
				proposal => Date().getTime() > Number(proposal.duration) + '000'
			)
		)

	return (
		<div className='flex flex-col p-8'>
			<div className='flex justify-center items-center' role='group'>
				<button onClick={getAll} className={`rounded-l-full ${active}`}>
					All
				</button>
				<button onClick={getOpened} className={`${deactivate}`}>
					OPEN
				</button>
				<button onClick={getClosed} className={`rounded-r-full ${deactivate}`}>
					CLOSE
				</button>
			</div>

			<div className='overflow-x-auto'>
				<div className='py-2 inline-block min-w-full '>
					<div className='h-[calc(100vh_-_20rem)] overflow-y-auto shadow-md rounded-md'>
						<table className='min-w-full'>
							<thead className='border-b dark:border-gray-500'>
								<tr>
									<th
										scope='col'
										className='text-sm font-medium px-6 py-4 text-left'
									>
										{' '}
										Beneficiary
									</th>
									<th
										scope='col'
										className='text-sm font-medium px-6 py-4 text-left'
									>
										{' '}
										Title
									</th>
									<th
										scope='col'
										className='text-sm font-medium px-6 py-4 text-left'
									>
										{' '}
										Expires
									</th>
									<th
										scope='col'
										className='text-sm font-medium px-6 py-4 text-left'
									>
										{' '}
										Action
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td className='text-sm font-light px-6 py-4 whitespace-nowrap'>
										<div className='flex justify-start items-center space-x-2'>
											<Identicons
												string={''}
												size={25}
												className='h-10 w-10 object-contain rounded-full'
											/>
											<span>0x00...0000</span>
										</div>
									</td>
									<td className='text-sm font-light px-6 py-4 whitespace-nowrap'>
										{proposal.title.substring(0, 80) + '...'}
									</td>
									<td className='text-sm font-light px-6 py-4 whitespace-nowrap'>
										{new Date().getTime() > Number(proposal.duration + '000')
											? 'Expired'
											: daysRemaining(proposal.duration)}
									</td>
									<td className='text-sm font-light px-6 py-4 whitespace-nowrap space-x-2'>
										<Link
											to={`/proposal/` + proposal.id}
											className='bg-blue-600 px-4 py-2.5 font-medium text-white text-sm 
                                  leading-tight uppercase shadow-md  shadow-gray-400 active:bg-blue-800 dark:shadow-transparent transition duration-150 ease-in-out dark:border dark:border-blue-500  border: border-blue-600 hover:text-white rounded-full'
										>
											View
										</Link>
										{new Date().getTime() >
										Number(proposal.duration) + '000' ? (
											proposal.upvotes > proposal.downvotes ? (
												!proposal.paid ? (
													<button
														className='bg-orange-600 px-4 py-2.5 font-medium text-white text-sm 
                                  leading-tight uppercase shadow-md  shadow-gray-400 active:bg-orange-800 dark:shadow-transparent transition duration-150 ease-in-out dark:border dark:border-orange-500  border: border-orange-600 hover:text-white rounded-full'
													>
														Payout
													</button>
												) : (
													<button
														className='bg-green-600 px-4 py-2.5 font-medium text-white text-sm 
                                  leading-tight uppercase shadow-md  shadow-gray-400 active:bg-green-800 dark:shadow-transparent transition duration-150 ease-in-out dark:border dark:border-green-500  border: border-green-600 hover:text-white rounded-full'
													>
														Paid
													</button>
												)
											) : (
												<button
													className='bg-red-600 px-4 py-2.5 font-medium text-white text-sm 
                                  leading-tight uppercase shadow-md  shadow-gray-400 active:bg-red-800 dark:shadow-transparent transition duration-150 ease-in-out dark:border dark:border-red-500  border: border-red-600 hover:text-white rounded-full'
												>
													Rejected
												</button>
											)
										) : null}
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	)
}

export default Proposals
