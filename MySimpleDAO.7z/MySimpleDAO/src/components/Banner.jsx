import React, { useState } from 'react'
import { toast } from 'react-toastify'
import { performContribute } from '../Blockchain.services'
import { setGlobalState, useGlobalState } from '../store'

const Banner = () => {
	const [amount, setAmount] = useState('')
	const [isStakeholder] = useGlobalState('isStakeholder')
	const [proposals] = useGlobalState('proposals')
	const [balance] = useGlobalState('balance')
	const [myBalance] = useGlobalState('myBalance')

	const onContribute = async () => {
		if (!!!amount || amount == '') return
		await performContribute(amount)
		toast.success('Contribution received')
		setAmount('')
	}

	const getOpened = () =>
		proposals.filter(
			proposal => Date().getTime() < Number(proposal.duration) + '000'
		).length

	return (
		<div className='p-8'>
			<h2 className='font-semibold text-3xl mb-5'>
				{getOpened()} Proposals Currently Opened
			</h2>
			<p>
				Current DAO Balance: <strong>{balance} ETH</strong>
				<br />
				Your Contributions:{' '}
				<span>
					<strong>{myBalance} ETH</strong>
					{isStakeholder ? ', and you are now a stakeholder' : null}
				</span>
			</p>
			<hr className='my-6 border-x-gray-300 dark:border-gray-500' />
			<p>
				{isStakeholder
					? 'You can now raise proposals on this platform'
					: 'When you contribute up to 1 ETH you become a stakeholder'}
			</p>
			<div className='flex justify-start items-center md:w-1/3 w-full mt-4'>
				<input
					type='number'
					className='form-control block w-full px-3 py-1.5 text-base font-normal text-gray-700 bg-clip-padding border border-solid border-x-gray-700 dark:bg-transparent rounded transition ease-in-out m-0 shadow-md focus:text-gray-500 focus:outline-none dark:border-gray-500'
					onChange={e => setAmount(e.target.value)}
					value={amount}
					placeholder='E.g. 3.2 ETH'
					required
				/>
			</div>

			<div className='flex justify-start items-center space-x-2 mt-4'>
				<button
					className='inline-block px-6 py-2.5 bg-blue-400 text-white font-medium text-sm leading-tight uppercase shadow-md shadow-gray-500 rounded-full dark:shadow-transparent hover:bg-blue-600'
					onClick={onContribute}
				>
					Contribute
				</button>
				{isStakeholder ? (
					<button
						className='inline-block px-6 py-2.5 bg-blue-400 text-white font-medium text-sm leading-tight uppercase shadow-md shadow-gray-500 rounded-full dark:shadow-transparent hover:bg-blue-600'
						onClick={() => setGlobalState('modal', 'scale-100')}
					>
						Propose
					</button>
				) : null}
			</div>
		</div>
	)
}

export default Banner
