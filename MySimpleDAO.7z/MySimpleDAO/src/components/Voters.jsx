import moment from 'moment'
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { listVoters } from '../Blockchain.services'
import { truncate } from '../store'

const Voters = () => {
	const [voters, setVoters] = useState([])
	const [data, setData] = useState([])
	const { id } = useParams()

	useEffect(async () => {
		await listVoters(id).then(res => {
			setVoters(res)
			setData(res)
		})
	}, [id])

	const getAll = () => setVoters(data)
	const getAccepted = () => setVoters(data.filter(vote => vote.chosen))
	const getRejected = () => setVoters(data.filter(vote => !vote.chosen))

	const active = `bg-blue-600 px-4 py-2.5 font-medium text-white text-xm 
        leading-tight uppercase shadow-md shadow-gray-400 active:bg-blue-800 dark:shadow-transparent transition duration-150 ease-in-out 
        dark:border dark:border-blue-500  border: border-blue-600 hover:text-white`

	const deactivate = `bg-transparent px-4 py-2.5 font-medium  text-xm 
        leading-tight uppercase text-blue-600 shadow-md shadow-gray-400 active:bg-blue-800 dark:shadow-transparent transition duration-150 ease-in-out 
        dark:border dark:border-blue-500  border: border-blue-600 hover:text-white hove:bg:blue-600`

	return (
		<div className='flex flex-col p-8'>
			<div className='flex justify-center items-center' role='group'>
				<button onClick={getAll} className={`rounded-l-full ${active}`}>
					All
				</button>
				<button onClick={getAccepted} className={`${deactivate}`}>
					Acceptees
				</button>
				<button
					onClick={getRejected}
					className={`rounded-r-full ${deactivate}`}
				>
					Rejectees
				</button>
			</div>

			<div className='overflow-x-auto'>
				<div className='py-2 inline-block min-w-full '>
					<div className='h-[calc(100vh_-_20rem)] overflow-y-auto shadow-md rounded-md'>
						<table className='min-w-full'>
							<thead className='border-b dark:border-gray-500'>
								<tr>
									<th
										scope='col'
										className='text-sm font-medium px-6 py-4 text-left'
									>
										{' '}
										Voter
									</th>
									<th
										scope='col'
										className='text-sm font-medium px-6 py-4 text-left'
									>
										{' '}
										Voted
									</th>
									<th
										scope='col'
										className='text-sm font-medium px-6 py-4 text-left'
									>
										{' '}
										Vote
									</th>
								</tr>
							</thead>
							<tbody>
								{voters.map((voter, i) => (
									<Voter key={i} vote={voter} />
								))}
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	)
}

const Voter = ({ vote }) => {
	const timeAgo = timestamp => moment(Number(timestamp + '000')).fromNow()
	return (
		<tr>
			<td className='text-sm font-light px-6 py-4 whitespace-nowrap'>
				<div className='flex justify-start items-center space-x-2'>
					<Identicons
						string={vote.voter}
						size={25}
						className='h-10 w-10 object-contain rounded-full'
					/>
					<span>{truncate(vote.voter, 4, 4, 11)}</span>
				</div>
			</td>
			<td className='text-sm font-light px-6 py-4 whitespace-nowrap'>
				{timeAgo(vote.timestamp)}
			</td>
			<td className='text-sm font-light px-6 py-4 whitespace-nowrap space-x-2'>
				{voter.chosen ? (
					<button
						className='bg-blue-600 px-4 py-2.5 font-medium text-white text-sm 
                                  leading-tight uppercase shadow-md  shadow-gray-400 active:bg-blue-800 dark:shadow-transparent transition duration-150 ease-in-out dark:border dark:border-blue-500  border: border-blue-600 hover:text-white rounded-full'
					>
						Accepted
					</button>
				) : (
					<button
						className='bg-red-600 px-4 py-2.5 font-medium text-white text-sm 
                                  leading-tight uppercase shadow-md  shadow-gray-400 active:bg-red-800 dark:shadow-transparent transition duration-150 ease-in-out dark:border dark:border-red-500  border: border-red-600 hover:text-white rounded-full'
					>
						Rejected
					</button>
				)}
			</td>
		</tr>
	)
}

export default Voters
