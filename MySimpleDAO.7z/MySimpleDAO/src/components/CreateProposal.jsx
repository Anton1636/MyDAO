import React from 'react'
import { FaTimes } from 'react-icons/fa'
import { useGlobalState } from '../store'

const CreateProposal = () => {
	const [modal] = useGlobalState('modal')

	return (
		<div
			className={`fixed top-0 left-0 w-screen h-screen flex items-center justify-center bg-black bg-opacity-50 transform transition-transform duration-300 ${modal} z-50`}
		>
			<div
				className='bg-white dark:bg-[#212936] shadow-lg shadow-[#122643] dark:shadow-gray-500 rounded-xl 
    w-11/12 md:w-2/5 h-712 p-6'
			>
				<form className='flex flex-col'>
					<div className='flex justify-between items-center'>
						<p className='font-semibold'>Raise Proposal</p>
						<button
							type='button'
							className='border-o bg-transparent focus:outline-none'
						>
							<FaTimes />
						</button>
					</div>

					<div className='flex justify-between items-center border border-gray-500 rounded-xl mt-5'>
						<input
							className='block w-full text-sm bg-transparent border-0 focus:outline-none focus:ring-0'
							type='text'
							name='title'
							placeholder='Title'
							required
						/>
					</div>

					<div className='flex justify-between items-center border border-gray-500 rounded-xl mt-5'>
						<input
							className='block w-full text-sm bg-transparent border-0 focus:outline-none focus:ring-0'
							type='number'
							name='amount'
							placeholder='E.g. 2.3 ETH'
							required
						/>
					</div>

					<div className='flex justify-between items-center border border-gray-500 rounded-xl mt-5'>
						<input
							className='block w-full text-sm bg-transparent border-0 focus:outline-none focus:ring-0'
							type='text'
							name='beneficiary'
							placeholder='0x0e...0aa0'
							required
						/>
					</div>

					<div className='flex justify-between items-center border border-gray-500 rounded-xl mt-5'>
						<textarea
							className='block w-full text-sm bg-transparent border-0
							focus:outline-none focus:ring-0'
							type='text'
							name='description'
							placeholder='Description'
							required
						></textarea>
					</div>

					<button className='px-6 py-2.5 bg-blue-600 font-medium mt-5 text-sm leading-tight uppercase rounded-full text-white   active:bg-blue-800 transition duration-150 ease-in-out dark:text-blue-700 '>
						Submit Proposal
					</button>
				</form>
			</div>
		</div>
	)
}

export default CreateProposal
