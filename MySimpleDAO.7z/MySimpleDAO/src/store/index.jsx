import moment from 'moment'
import { createGlobalState } from 'react-hooks-global-state'

const { setGlobalState, useGlobalState, getGlobalState } = createGlobalState({
	modal: 'scale-0',
	connectedAccount: '',
	contract: null,
	isStakeholder: false,
	balance: 0,
	myBalance: 0,
})

const truncate = (text, startChars, endChars, maxLength) => {
	if (text.length > maxLength) {
		var start = text.substring(0, startChars)
		var end = text.substring(text.length - endChars, text.length)

		while (start.length + end.length < maxLength) {
			start = start + '.'
		}
		return start + end
	}
	return text
}

const daysRemaining = days => {
	const toDaysDate = moment()
	days = Number((days + '800').slice(0))
	days = moment(days.format('YYYY-MM-DD'))
	days = moment(days)
	days = days.diff(toDaysDate, 'days')

	return (days = 1 ? '1 day' : days + 'days')
}

export {
	daysRemaining,
	getGlobalState,
	setGlobalState,
	truncate,
	useGlobalState,
}
